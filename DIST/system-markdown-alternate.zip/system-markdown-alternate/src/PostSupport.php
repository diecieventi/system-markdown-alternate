<?php
/**
 * @package Diecieventi\SystemMarkdownAlternate
 */

namespace Diecieventi\SystemMarkdownAlternate;

defined( 'ABSPATH' ) || exit;

/**
 * Shared eligibility rules for posts that expose a Markdown version.
 *
 * Single source of truth for the .md endpoint, content negotiation, alternate link,
 * shortcode [sysmda_md_url] e dynamic tag {{sysmda_md_url}}.
 */
class PostSupport {

	/**
	 * Post types that are never servable, whatever the settings or the filter say.
	 *
	 * Media is always excluded (durable product decision): an attachment page is
	 * not editorial content and has no Markdown representation to offer.
	 */
	const NEVER_SERVABLE = array( 'attachment' );

	/**
	 * Post formats whose posts never expose a Markdown version.
	 *
	 * Every non-standard format: an aside, status, link or quote is a short
	 * snippet, usually untitled, that carries no editorial body worth serving as
	 * a document. Posts with the standard format (get_post_format() === false)
	 * are unaffected, which is the overwhelming majority of content.
	 */
	const EXCLUDED_POST_FORMATS = array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' );

	/**
	 * Supported post types (filterable). An empty list means the plugin is inactive.
	 *
	 * Memoized per blog: the value is keyed on the current blog ID so a
	 * switch_to_blog() loop (WP-CLI, network cron, a multisite aggregator) does
	 * not evaluate one site's posts against another site's settings.
	 *
	 * @return string[]
	 */
	public static function supported_post_types(): array {
		static $types = array();

		$blog_id = function_exists( 'get_current_blog_id' ) ? (int) get_current_blog_id() : 0;

		if ( ! isset( $types[ $blog_id ] ) ) {
			/** Filters post types that expose the .md endpoint and alternate link. */
			$types[ $blog_id ] = self::sanitize_types( (array) apply_filters( 'sysmda_markdown_supported_post_types', array() ) );
		}

		return $types[ $blog_id ];
	}

	/**
	 * Normalizes a supported-types list and drops the never-servable ones.
	 *
	 * The settings page already keeps `attachment` out of the saved option, but
	 * the filter is a public extension point: enforcing the rule here keeps it
	 * true for every consumer (.md endpoint, negotiation, alternate link,
	 * /llms.txt), not just for values coming from the panel.
	 *
	 * @param array $types Raw list, as returned by the filter.
	 * @return string[] Normalized list, without duplicates or excluded types.
	 */
	public static function sanitize_types( array $types ): array {
		$clean = array();

		foreach ( $types as $type ) {
			if ( ! is_string( $type ) ) {
				continue;
			}

			$type = trim( $type );

			if ( '' === $type
				|| in_array( $type, self::NEVER_SERVABLE, true )
				|| in_array( $type, $clean, true ) ) {
				continue;
			}

			$clean[] = $type;
		}

		return $clean;
	}

	/**
	 * Whether the post exposes a .md representation: supported type, published,
	 * not password-protected, and not carrying an excluded post format.
	 *
	 * The password test reads `post_password` directly and deliberately NOT
	 * `post_password_required()`, which answers a different question: "does this
	 * visitor still have to supply it?". That returns false as soon as a valid
	 * `wp-postpass_*` cookie exists, so a reader who had entered the password
	 * once also unlocked the `.md`, the `rel="alternate"` link, the shortcode and
	 * the dynamic tag. The rule is "protected content has no Markdown
	 * representation at all" — see the decision in AGENTS.md — so having the
	 * password is irrelevant. This also makes the endpoint agree with
	 * `/llms.txt`, which has always filtered on `has_password => false`.
	 */
	public static function is_servable( \WP_Post $post ): bool {
		return in_array( $post->post_type, self::supported_post_types(), true )
			&& 'publish' === $post->post_status
			&& '' === (string) $post->post_password
			&& ! self::has_excluded_post_format( $post );
	}

	/**
	 * Whether the post carries a post format that is excluded from Markdown.
	 *
	 * Checked last in is_servable(): it is the only rule that may need a term
	 * lookup, and the cheaper checks usually settle the question first.
	 */
	public static function has_excluded_post_format( \WP_Post $post ): bool {
		/**
		 * Filters the post formats excluded from the Markdown representation.
		 *
		 * Defaults to every non-standard format. Return an empty array to serve
		 * them all again, or a shorter list to exclude only some. The standard
		 * format is never affected: it is the absence of a format, not a value.
		 *
		 * @param string[] $formats Excluded format slugs (without the `post-format-` prefix).
		 * @param \WP_Post $post    Post being evaluated.
		 */
		$excluded = (array) apply_filters( 'sysmda_markdown_excluded_post_formats', self::EXCLUDED_POST_FORMATS, $post );

		if ( empty( $excluded ) ) {
			return false;
		}

		$format = get_post_format( $post );

		// false (standard format) or a post type without format support.
		if ( ! is_string( $format ) || '' === $format ) {
			return false;
		}

		return in_array( $format, $excluded, true );
	}
}
