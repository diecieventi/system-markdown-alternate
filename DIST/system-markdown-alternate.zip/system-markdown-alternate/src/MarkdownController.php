<?php
/**
 * @package Diecieventi\SystemMarkdownAlternate
 */

namespace Diecieventi\SystemMarkdownAlternate;

defined( 'ABSPATH' ) || exit;

/**
 * Intercepts *.md requests and content negotiation, validates the post,
 * serves Markdown, and prints the alternate link.
 */
class MarkdownController {

	/** @var ContentRenderer */
	private $renderer;

	/** @var MarkdownConverter */
	private $converter;

	/** @var MetadataBuilder */
	private $metadata;

	public function __construct( ContentRenderer $renderer, MarkdownConverter $converter, MetadataBuilder $metadata ) {
		$this->renderer  = $renderer;
		$this->converter = $converter;
		$this->metadata  = $metadata;
	}

	/**
	 * Hook: template_redirect (priority 0).
	 *
	 * 1. .md suffix: resolves the post, validates it, and serves Markdown.
	 * 2. Content negotiation on the canonical permalink: the same URL can return
	 *    HTML or Markdown depending on the `Accept` header (with q-values) or
	 *    `?format=markdown`. Every servable URL declares `Vary: Accept` so caches
	 *    and proxies do not mix the two representations.
	 */
	public function maybe_render_markdown(): void {
		// No enabled content type: the plugin is inactive and must not touch the
		// request at all — not even to redirect a .md URL it would then 404.
		if ( empty( PostSupport::supported_post_types() ) ) {
			return;
		}

		// --- .md suffix route ---
		$post = $this->resolve_requested_post();

		if ( $post instanceof \WP_Post ) {
			if ( ! $this->is_servable( $post ) ) {
				$this->force_404();
				return;
			}
			$this->serve_markdown( $post );
		}

		// --- Content negotiation on the canonical permalink ---
		if ( ! $this->is_negotiable_request() ) {
			return; // Not negotiable: WP continues with normal rendering.
		}

		$queried = get_queried_object();

		// This URL varies by Accept: declare it to caches/CDNs/proxies whether
		// responding with Markdown or leaving HTML rendering to WordPress.
		$this->send_vary_header();

		if ( $this->prefers_markdown() ) {
			// The negotiated Markdown shares its URL with the HTML page: page
			// caches that key by URL only (observed on some LiteSpeed setups,
			// which ignore Vary: Accept) must never store this variant, or it
			// would be served to HTML clients too. .md URLs stay cacheable.
			// Sent before serve_markdown() so both the 200 and the conditional
			// 304 exits carry the no-cache invariant.
			$this->send_no_cache_headers();
			$this->serve_markdown( $queried );
		}

		if ( $this->should_reject_unacceptable() ) {
			$this->send_no_cache_headers();
			$this->send_not_acceptable();
			exit;
		}

		// Default: WordPress serves HTML (Vary: Accept already sent).
	}

	/**
	 * Whether the current request may be answered with the negotiated Markdown
	 * representation of the queried post.
	 *
	 * Only the canonical singular permalink negotiates. `is_singular` alone is
	 * not enough: it stays true for a post's feed, its oEmbed view, its trackback
	 * endpoint, its paged comments and the sub-pages of a `<!--nextpage-->` post,
	 * so `Accept: text/markdown` on `/my-post/feed/` used to return the article
	 * body instead of the feed. Those URLs are variants of the post, not the post,
	 * and `markdown_url()` never advertises them.
	 *
	 * Matches the guard used by print_alternate_link(): what declares
	 * `Vary: Accept` and what advertises a Markdown alternate stay in step.
	 */
	private function is_negotiable_request(): bool {
		if ( is_feed() || is_embed() || is_trackback() ) {
			return false;
		}

		if ( ! is_singular( PostSupport::supported_post_types() ) ) {
			return false;
		}

		// Paged comments (/comment-page-2/) and post sub-pages (/my-post/2/) are
		// separate URLs whose Markdown would duplicate the canonical one.
		if ( (int) get_query_var( 'cpage' ) > 0 || (int) get_query_var( 'page' ) > 1 ) {
			return false;
		}

		$queried = get_queried_object();

		return $queried instanceof \WP_Post && $this->is_servable( $queried );
	}

	/**
	 * Hook: wp_head. Prints the alternate link only on supported public posts/CPTs.
	 */
	public function print_alternate_link(): void {
		$types = PostSupport::supported_post_types();

		// Explicit guard: is_singular([]) in WP is true for ANY singular content.
		// With no selected types, the plugin is inactive and must not print the link.
		if ( empty( $types ) || ! is_singular( $types ) ) {
			return;
		}

		$post = get_queried_object();

		if ( ! $post instanceof \WP_Post || ! $this->is_servable( $post ) ) {
			return;
		}

		printf(
			'<link rel="alternate" type="text/markdown" href="%s" />' . "\n",
			esc_url( MetadataBuilder::markdown_url( $post ) )
		);
	}

	/**
	 * Hook: save_post / deleted_post. Deletes the post's Markdown cache and the
	 * /llms.txt index so new posts, changes, and deletions are reflected immediately.
	 *
	 * Skips revisions and autosaves: save_post fires continuously while editing,
	 * and those IDs do not have their own cache.
	 */
	public function invalidate_cache( int $post_id ): void {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		Cache::delete( 'sysmda_md_' . $post_id );
		Cache::delete( LlmsTxtController::CACHE_KEY );
	}

	// ─── Resolution ───────────────────────────────────────────────────────────

	/**
	 * Resolves the post from a REQUEST_URI ending in `.md`.
	 *
	 * Handles query strings and trailing slashes (`/slug.md/` → 301 to `/slug.md`).
	 */
	private function resolve_requested_post(): ?\WP_Post {
		if ( empty( $_SERVER['REQUEST_URI'] ) ) {
			return null;
		}

		$request_uri = wp_unslash( $_SERVER['REQUEST_URI'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$path        = wp_parse_url( $request_uri, PHP_URL_PATH );

		if ( ! is_string( $path ) || '' === $path ) {
			return null;
		}

		$path = rawurldecode( $path );

		// Trailing slash: /slug.md/ → 301 to /slug.md. The suffix is matched
		// case-insensitively (a hand-typed or copied `.MD` should resolve too).
		if ( (bool) preg_match( '#\.md/+$#i', $path ) ) {
			$target = preg_replace( '#\.md/+$#i', '.md', $path );
			$query  = wp_parse_url( $request_uri, PHP_URL_QUERY );
			if ( $query ) {
				$target .= '?' . $query;
			}
			wp_safe_redirect( $target, 301 );
			exit;
		}

		if ( 0 !== strcasecmp( '.md', substr( $path, -3 ) ) ) {
			return null;
		}

		$clean_path = substr( $path, 0, -3 );

		$post_id = url_to_postid( $this->build_site_url( $clean_path ) );

		if ( ! $post_id ) {
			$post_id = url_to_postid( $this->build_site_url( trailingslashit( $clean_path ) ) );
		}

		if ( ! $post_id ) {
			return null;
		}

		$post = get_post( $post_id );

		return $post instanceof \WP_Post ? $post : null;
	}

	/**
	 * Whether the client explicitly prefers Markdown over HTML.
	 *
	 * Markdown is served only when explicitly requested:
	 * - `?format=markdown` (application override), or
	 * - `text/markdown` listed in Accept with q ≥ the effective q of
	 *   `text/html`.
	 *
	 * A wildcard-only Accept (`text/*` or a full wildcard), or a missing Accept,
	 * does NOT activate Markdown: HTML remains the site default. Clients that
	 * send a wildcard Accept (curl and many HTTP libraries) therefore receive HTML.
	 */
	private function prefers_markdown(): bool {
		if ( isset( $_GET['format'] ) && 'markdown' === $_GET['format'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			return true;
		}

		$accept = $this->accept_header();
		if ( '' === $accept ) {
			return false;
		}

		$md = AcceptNegotiator::explicit_quality( $accept, 'text/markdown' );
		if ( null === $md || $md <= 0.0 ) {
			return false;
		}

		return $md >= AcceptNegotiator::quality( $accept, 'text/html' );
	}

	/**
	 * Whether the client's Accept header rejects EVERY offered representation
	 * (neither HTML nor Markdown, and no wildcard), making it a candidate for
	 * `406 Not Acceptable`.
	 *
	 * Real clients (browsers, crawlers, agents) always send `text/html` or a
	 * wildcard and are never affected. Can be disabled through the
	 * `sysmda_markdown_strict_406` filter (RFC 9110 makes 406 optional, so serving
	 * the default representation is still valid).
	 */
	private function should_reject_unacceptable(): bool {
		/** Filter: send 406 when Accept allows neither HTML nor Markdown. */
		if ( ! apply_filters( 'sysmda_markdown_strict_406', true ) ) {
			return false;
		}

		if ( isset( $_GET['format'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return false;
		}

		$accept = $this->accept_header();
		if ( '' === $accept ) {
			return false; // No Accept header means any representation is acceptable.
		}

		return AcceptNegotiator::quality( $accept, 'text/html' ) <= 0.0
			&& AcceptNegotiator::quality( $accept, 'text/markdown' ) <= 0.0;
	}

	/**
	 * Normalized request `Accept` header (empty string when absent).
	 */
	private function accept_header(): string {
		return isset( $_SERVER['HTTP_ACCEPT'] ) ? trim( (string) wp_unslash( $_SERVER['HTTP_ACCEPT'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	}

	/**
	 * Adds `Vary: Accept` without duplicating an existing Vary header that includes it.
	 */
	private function send_vary_header(): void {
		if ( headers_sent() ) {
			return;
		}

		foreach ( headers_list() as $sent ) {
			if ( 0 === stripos( $sent, 'vary:' ) && false !== stripos( $sent, 'accept' ) ) {
				return; // Already covered.
			}
		}

		header( 'Vary: Accept', false );
	}

	/**
	 * Marks the current response as non-cacheable for every cache in front of
	 * PHP (negotiated Markdown and 406 responses only, never `.md` URLs).
	 *
	 * Honouring `Vary: Accept` is a per-host property: the default LiteSpeed
	 * cache keys by URL only and ignores it, and CDNs may too. These responses
	 * share their URL with the HTML page, so the standard `Cache-Control`
	 * no-cache header is a server-agnostic security invariant — it must never
	 * depend on a specific cache plugin being active. The LiteSpeed-specific
	 * signals (header, DONOTCACHEPAGE, LSCWP action) stay in LiteSpeedCompat.
	 */
	private function send_no_cache_headers(): void {
		if ( ! headers_sent() ) {
			header( 'Cache-Control: no-cache, no-store, must-revalidate, private' );
		}

		LiteSpeedCompat::mark_nocache();
	}

	/**
	 * Minimal `406 Not Acceptable` response (the URL offers only HTML/Markdown).
	 */
	private function send_not_acceptable(): void {
		if ( headers_sent() ) {
			return;
		}

		status_header( 406 );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo "406 Not Acceptable\n";
	}

	/**
	 * Builds an absolute URL using the trusted scheme/host from home_url() and the request path.
	 * Also supports subdirectory installations and prevents HTTP_HOST spoofing.
	 */
	private function build_site_url( string $path ): string {
		$home  = wp_parse_url( home_url() );
		$parts = is_array( $home ) ? $home : array();

		$scheme = isset( $parts['scheme'] ) ? $parts['scheme'] : ( is_ssl() ? 'https' : 'http' );
		$host   = isset( $parts['host'] ) ? $parts['host'] : '';
		$port   = isset( $parts['port'] ) ? ':' . $parts['port'] : '';

		return $scheme . '://' . $host . $port . '/' . ltrim( $path, '/' );
	}

	// ─── Validation ───────────────────────────────────────────────────────────

	/**
	 * Checks whether the post can be served as Markdown (see PostSupport).
	 */
	private function is_servable( \WP_Post $post ): bool {
		return PostSupport::is_servable( $post );
	}

	/**
	 * Sets the 404 status while leaving template rendering to WordPress.
	 */
	private function force_404(): void {
		global $wp_query;

		if ( $wp_query instanceof \WP_Query ) {
			$wp_query->set_404();
		}

		status_header( 404 );
		nocache_headers();
	}

	// ─── Cache & output ───────────────────────────────────────────────────────

	/**
	 * Serves a post's Markdown representation and ends the request.
	 *
	 * Before the body, handles conditional requests (If-None-Match /
	 * If-Modified-Since): if the client already has the current version, returns
	 * 304 without a body. Otherwise sends the headers (including ETag and
	 * Last-Modified) and the Markdown. Used by both the .md suffix branch and
	 * content negotiation so validation logic remains centralized.
	 */
	private function serve_markdown( \WP_Post $post ): void {
		// Counts 200 and 304 alike (an access is an access), for both the .md
		// suffix and the negotiated permalink: every path serving Markdown
		// goes through this method.
		$this->maybe_record_hit();

		$version = $this->cache_version( $post );

		if ( $this->handle_conditional( $post, $version ) ) {
			exit; // 304 already sent, no body.
		}

		$this->send_headers( $post, $version );
		echo $this->get_markdown( $post, $version ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/**
	 * Records the response in the daily `.md` hit counter when the opt-in
	 * `sysmda_md_hits_enabled` option is on (default off).
	 *
	 * The user agent is read only so HitCounter can classify bot vs human;
	 * it is never stored (count-only privacy decision, see HitCounter).
	 */
	private function maybe_record_hit(): void {
		if ( '1' !== get_option( 'sysmda_md_hits_enabled', '0' ) ) {
			return;
		}

		$ua = isset( $_SERVER['HTTP_USER_AGENT'] )
			? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			: null;

		HitCounter::record( $ua );
	}

	/**
	 * Handles conditional requests. Returns true (and sends 304) when the client
	 * already has the current version of the resource.
	 *
	 * Validators:
	 * - Strong ETag = "{cache_version}" (changes after an edit, plugin update, or
	 *   settings save: it uses the same cache hash, so a 304 always means the body
	 *   would be identical to the cached one).
	 * - Last-Modified = post_modified_gmt (RFC 7231).
	 *
	 * If-None-Match takes precedence (RFC 9110): when present, it alone determines
	 * the result (match → 304, no match → full body), and If-Modified-Since is ignored.
	 * If-Modified-Since is additionally ignored whenever the date is not a strong
	 * validator for this representation (see date_is_strong_validator()).
	 */
	private function handle_conditional( \WP_Post $post, string $version ): bool {
		$etag        = '"' . $version . '"';
		$modified_ts = $this->last_modified_timestamp( $post );

		$if_none_match = isset( $_SERVER['HTTP_IF_NONE_MATCH'] )
			? trim( (string) wp_unslash( $_SERVER['HTTP_IF_NONE_MATCH'] ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			: '';

		if ( '' !== $if_none_match ) {
			if ( self::etag_matches( $if_none_match, $etag ) ) {
				$this->send_not_modified( $etag, $modified_ts );
				return true;
			}
			return false; // INM is present but does not match: it takes precedence, so serve the full body.
		}

		$if_modified_since = isset( $_SERVER['HTTP_IF_MODIFIED_SINCE'] )
			? trim( (string) wp_unslash( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			: '';

		// If-Modified-Since may only be trusted while `post_modified_gmt` fully
		// determines the representation. With custom taxonomies emitted it does
		// not: assigning or renaming a term changes the body without touching
		// that date, so honouring the date here would answer 304 with stale
		// terms for a client that sends no If-None-Match. The ETag does carry
		// the taxonomy fingerprint, so it stays the reliable validator and the
		// date is downgraded to informational (still sent in the response).
		if ( '' !== $if_modified_since && $modified_ts > 0 && $this->date_is_strong_validator( $post ) ) {
			$since = strtotime( $if_modified_since );
			if ( false !== $since && $modified_ts <= $since ) {
				$this->send_not_modified( $etag, $modified_ts );
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether `post_modified_gmt` alone determines the emitted Markdown.
	 *
	 * False as soon as something can change the output without touching the
	 * post's modification date — today only the optional taxonomy block.
	 */
	private function date_is_strong_validator( \WP_Post $post ): bool {
		return '' === MetadataBuilder::taxonomies_fingerprint( $post );
	}

	/**
	 * Checks whether an If-None-Match header matches the resource ETag.
	 *
	 * Handles the `*` wildcard, comma-separated ETag lists, and the weak `W/`
	 * prefix (removed before comparison, which still uses the quoted value).
	 *
	 * Public only so it can be tested in isolation (pure string logic).
	 */
	public static function etag_matches( string $header, string $etag ): bool {
		$header = trim( $header );

		if ( '*' === $header ) {
			return true;
		}

		foreach ( explode( ',', $header ) as $candidate ) {
			$candidate = trim( $candidate );

			if ( 0 === stripos( $candidate, 'W/' ) ) {
				$candidate = substr( $candidate, 2 );
			}

			if ( $candidate === $etag ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Unix timestamp of the last modification (from post_modified_gmt), or 0 if invalid.
	 */
	private function last_modified_timestamp( \WP_Post $post ): int {
		$modified = (string) $post->post_modified_gmt;

		if ( '' === $modified || '0000-00-00 00:00:00' === $modified ) {
			return 0;
		}

		$ts = strtotime( $modified . ' GMT' );

		return false !== $ts ? $ts : 0;
	}

	/**
	 * Sends a 304 Not Modified response: validation headers only, no body.
	 */
	private function send_not_modified( string $etag, int $modified_ts ): void {
		if ( headers_sent() ) {
			return;
		}

		status_header( 304 );
		header( 'ETag: ' . $etag );

		if ( $modified_ts > 0 ) {
			header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', $modified_ts ) . ' GMT' );
		}
	}

	/**
	 * Retrieves Markdown from the transient cache or regenerates it.
	 *
	 * Key: `sysmda_md_{post_id}`. The value includes a version hash
	 * (post_modified_gmt + plugin version + settings salt) to detect changes
	 * without leaving orphaned keys. It is proactively invalidated:
	 * - when the post is edited (post_modified_gmt changes)
	 * - when the plugin is updated (SYSMDA_VERSION changes)
	 * - when settings are saved (the salt changes; see AdminSettings)
	 * - by the save_post hook through invalidate_cache().
	 *
	 * @param string $version Validator computed by the caller (also the ETag), so
	 *                        the hash — and the term lookups behind it — are not
	 *                        recomputed for the same response.
	 */
	private function get_markdown( \WP_Post $post, string $version ): string {
		/** Filter: cache TTL in seconds. 0 disables the cache. */
		$ttl       = (int) apply_filters( 'sysmda_markdown_cache_ttl', DAY_IN_SECONDS, $post );
		$cache_key = 'sysmda_md_' . $post->ID;

		if ( $ttl > 0 ) {
			$cached = Cache::get( $cache_key );
			if ( is_array( $cached ) && isset( $cached['v'], $cached['md'] ) &&
				$cached['v'] === $version ) {
				return $cached['md'];
			}
		}

		$markdown = $this->build_markdown( $post );

		if ( $ttl > 0 ) {
			Cache::set(
				$cache_key,
				array(
					'v'  => $version,
					'md' => $markdown,
				),
				$ttl
			);
		}

		return $markdown;
	}

	/**
	 * Cache validity hash: changes when the post is edited, the plugin is updated,
	 * or settings are saved (global salt).
	 *
	 * This value is also the strong ETag, so it must change whenever the emitted
	 * Markdown changes. Term assignments and renames do NOT touch
	 * `post_modified_gmt`, so when custom taxonomies are emitted their data is
	 * fingerprinted in as well; without it a conditional request would keep
	 * answering `304` with outdated terms, even with the body cache disabled.
	 * The fingerprint is empty while the feature is off, which leaves the hash
	 * byte-identical to earlier versions (no mass invalidation on upgrade).
	 */
	private function cache_version( \WP_Post $post ): string {
		$salt       = (string) get_option( 'sysmda_cache_salt', '0' );
		$taxonomies = MetadataBuilder::taxonomies_fingerprint( $post );
		$taxonomies = '' !== $taxonomies ? '|' . $taxonomies : '';

		return md5( (string) $post->post_modified_gmt . '|' . SYSMDA_VERSION . '|' . $salt . $taxonomies );
	}

	/**
	 * Assembles front matter, H1 title, and converted body.
	 *
	 * The post is installed as the global `$post` (and the loop is set up) for
	 * the duration of the conversion. On the `.md` suffix route the main query
	 * resolved `/slug.md`, which matches nothing, so WordPress 404s and leaves
	 * `$GLOBALS['post']` null: dynamic blocks and shortcodes falling back to
	 * `get_the_ID()` would render against no post at all, and the same content
	 * would convert differently depending on whether it was reached through the
	 * `.md` suffix or through negotiation on the permalink.
	 */
	private function build_markdown( \WP_Post $post ): string {
		$previous_post = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;

		$GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restored below; render_block()/do_shortcode() need the loop context.
		setup_postdata( $post );

		try {
			// The whole assembly runs inside the post context, the filters
			// included: `sysmda_markdown_preamble` is where the ACF integration
			// renders the TL;DR through the same shortcode pipeline as the body,
			// so it needs the loop just as much.
			$front_matter = $this->metadata->build_front_matter( $post );
			$html         = $this->renderer->render( $post );
			$body         = $this->converter->convert( $html );

			$title = html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' );
			$title = trim( preg_replace( '/\s+/', ' ', $title ) );

			/** Filter: Markdown block between the # Title and body (subtitle, TL;DR, etc.). */
			$preamble = (string) apply_filters( 'sysmda_markdown_preamble', '', $post );

			$markdown = $front_matter . "\n# " . $title . "\n\n" . $preamble . $body;

			/** Filter: final Markdown (front matter + content). */
			$markdown = apply_filters( 'sysmda_markdown_output', $markdown, $post );
		} finally {
			if ( $previous_post instanceof \WP_Post ) {
				$GLOBALS['post'] = $previous_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restoring the caller's value.
				setup_postdata( $previous_post );
			} else {
				unset( $GLOBALS['post'] );
				wp_reset_postdata();
			}
		}

		return rtrim( $markdown ) . "\n";
	}

	/**
	 * Sends HTTP headers for the Markdown response.
	 *
	 * Always includes ETag and Last-Modified (the same validators used for
	 * conditional requests) so caches/proxies can store and revalidate them.
	 */
	private function send_headers( \WP_Post $post, string $version ): void {
		if ( headers_sent() ) {
			return;
		}

		status_header( 200 );
		header( 'Content-Type: text/markdown; charset=utf-8' );
		header( 'ETag: "' . $version . '"' );

		$modified_ts = $this->last_modified_timestamp( $post );
		if ( $modified_ts > 0 ) {
			header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', $modified_ts ) . ' GMT' );
		}

		/** Filter: X-Robots-Tag header. Empty string means the header is not sent. */
		$robots = apply_filters( 'sysmda_markdown_robots_header', 'noindex, follow', $post );

		// Both filter results are sanitized before reaching header(): a value
		// carrying a line break is rejected by PHP with a fatal error, and a
		// public extension point must not be able to take the response down.
		$robots = is_string( $robots ) ? sanitize_text_field( $robots ) : '';

		if ( '' !== $robots ) {
			header( 'X-Robots-Tag: ' . $robots );
		}

		/**
		 * Filter: canonical URL pointing to the HTML original (Link rel="canonical" header).
		 * Empty string means the header is not sent.
		 */
		$canonical = apply_filters( 'sysmda_markdown_canonical_url', get_permalink( $post ), $post );

		$canonical = is_string( $canonical ) ? esc_url_raw( $canonical ) : '';

		if ( '' !== $canonical ) {
			header( 'Link: <' . $canonical . '>; rel="canonical"', false );
		}
	}
}
